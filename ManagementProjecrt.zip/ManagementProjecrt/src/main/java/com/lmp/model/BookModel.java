package com.lmp.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BookModel {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long Id;
	private String bookname;
	private String author;
	private Date purchaseDate;
	
	

	public BookModel( String bookname, String author, Date purchaseDate) {
		super();
	
		this.bookname = bookname;
		this.author = author;
		this.purchaseDate = purchaseDate;
	}

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	@Override
	public String toString() {
		return "BookModel [Id=" + Id + ", bookname=" + bookname + ", author=" + author + ", purchaseDate="
				+ purchaseDate + "]";
	}

}
