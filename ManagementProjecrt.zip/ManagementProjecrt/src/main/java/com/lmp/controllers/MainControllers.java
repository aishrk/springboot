package com.lmp.controllers;

import java.util.Collection;

import org.h2.engine.Database;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.lmp.model.BookModel;
import com.lmp.service.BookService;

@Controller
public class MainControllers {
	@Autowired
	private BookService bookservices;
	@Autowired
private Database datasource;
	
	@GetMapping("/index")
	public String init() {
		return "index";
		
	}
	
	@GetMapping("/addAllBook")
	public Collection<BookModel> addAllbooks(){
		return bookservices.addBooks();
	}
	
	@GetMapping("/findallbook")
	public Collection<BookModel> findallbooks(){
		return bookservices.findAllBook();
	}

}
