package com.lmp.controller.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MainRestController {
	
	@GetMapping("/")
	public String displayPage() {
		return "welcome page";
		
	}

}
