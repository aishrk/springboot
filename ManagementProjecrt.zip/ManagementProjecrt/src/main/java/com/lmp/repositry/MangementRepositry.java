package com.lmp.repositry;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.lmp.model.BookModel;

@Repository
public interface MangementRepositry extends CrudRepository<BookModel,Long> {

}
