package com.lmp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagementProjecrtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagementProjecrtApplication.class, args);
	}

}
