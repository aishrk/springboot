package com.lmp.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lmp.model.BookModel;
import com.lmp.repositry.MangementRepositry;

@Service
public class BookService {
	
	@Autowired
	private MangementRepositry mangementRepositry;
	
	public  Collection<BookModel> findAllBook(){
		List<BookModel> list=new ArrayList<>();
		for (BookModel bookModel : mangementRepositry.findAll()) {
			list.add(bookModel);
		}
		return list;
	}
	
	public Collection<BookModel> addBooks(){
		List<BookModel>booklist=new ArrayList<>();
		booklist.add(new BookModel("javaSE","PK",new Date()));
		booklist.add(new BookModel("javaME","Shesha",new Date()));
		booklist.add(new BookModel("javaEE","radha",new Date()));
		booklist.add(new BookModel("javaAE","pq",new Date()));
		System.out.println(booklist);
		return booklist;
		
	}

}
